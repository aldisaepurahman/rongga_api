var mysql = require('mysql');

//create db connection
const conn = mysql.createConnection({
    host:'apirongga.noncognitive.my.id',
    user:'noncogni_rongga',
    password:'semogasukses',
    database:'noncogni_rongga_db'
});

conn.connect((err)=>{
    if (err) throw err;
    console.log('Mysql Connect');
});

module.exports = conn;